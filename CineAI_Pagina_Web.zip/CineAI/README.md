# CineAI — Asistente Inteligente de Películas

**Integrantes:** Santino Ponce, Leandro Berdun y Ciro Lezcano  
**Curso:** 5.º C  
**Fecha:** 29/10/2026

## Cómo abrir la página
1. Descargá y descomprimí `CineAI.zip`.
2. Abrí la carpeta `CineAI`.
3. Hacé doble clic en `index.html`. Se abre en el navegador.

## Módulos incluidos
- Inicio y navegación.
- Formulario con validación y contador de caracteres.
- Respuestas de demostración y tarjetas de películas.
- Historial de preguntas de la sesión.
- Recomendaciones por género.
- Accesos para resumen y traducción.
- Modo claro/oscuro.
- Diseño adaptable a computadoras, tablets y celulares.

## Nota sobre la inteligencia artificial
Esta entrega es un prototipo funcional de interfaz: simula respuestas para que puedan probar los módulos sin configurar cuentas ni claves. Para tener respuestas reales de ChatGPT/Gemini, hay que conectar una API mediante un servidor propio. No se debe guardar una clave secreta dentro de `script.js`, porque ese archivo puede verlo cualquier visitante.

## Tecnologías
HTML, CSS y JavaScript.
