const questionForm = document.getElementById('questionForm');
const questionInput = document.getElementById('questionInput');
const validationMessage = document.getElementById('validationMessage');
const charCount = document.getElementById('charCount');
const conversation = document.getElementById('conversation');
const historyList = document.getElementById('historyList');
const toast = document.getElementById('toast');
let historyItems = [];
let lastQuestion = '';
let lastAnswer = '';

const movieSets = {
  ciencia: [
    ['Interestelar','2014 · Ciencia ficción','Un viaje espacial emocionante sobre el tiempo, la familia y la supervivencia.','poster-space','ODISEA','ESPACIAL'],
    ['Matrix','1999 · Acción / Ciencia ficción','Un clásico que mezcla acción y preguntas sobre la realidad.','poster-neon','THE','MATRIX'],
    ['Blade Runner 2049','2017 · Ciencia ficción','Un futuro visualmente impactante con misterio y preguntas sobre la identidad.','poster-red','FUTURO','EN LLAMAS']
  ],
  accion: [
    ['Mad Max: Fury Road','2015 · Acción','Persecuciones intensas y un mundo postapocalíptico.','poster-red','MAD MAX','FURY ROAD'],
    ['Misión imposible: Fallout','2018 · Acción','Espionaje, misiones complicadas y escenas de riesgo.','poster-neon','MISIÓN','IMPOSIBLE'],
    ['Batman: El caballero de la noche','2008 · Acción / Drama','Un enfrentamiento lleno de tensión y decisiones difíciles.','poster-space','EL','CABALLERO']
  ],
  comedia: [
    ['Paddington 2','2017 · Comedia / Familia','Una aventura cálida y divertida para compartir.','poster-space','PADDINGTON','2'],
    ['Escuela de rock','2003 · Comedia / Música','Un músico transforma una clase con energía y humor.','poster-red','ESCUELA','DE ROCK'],
    ['Mi pobre angelito','1990 · Comedia / Familia','Un clásico familiar con situaciones disparatadas.','poster-neon','MI POBRE','ANGELITO']
  ],
  terror: [
    ['El conjuro','2013 · Terror','Una historia sobrenatural cargada de suspenso.','poster-red','EL','CONJURO'],
    ['Un lugar en silencio','2018 · Terror / Suspenso','Una familia debe sobrevivir en un mundo donde el ruido es peligroso.','poster-space','SILENCIO','TOTAL'],
    ['La noche del demonio','2010 · Terror','Misterio paranormal y una atmósfera inquietante.','poster-neon','LA NOCHE','DEL DEMONIO']
  ],
  default: [
    ['El origen','2010 · Ciencia ficción / Acción','Una historia de sueños, ideas y realidad con muchos giros.','poster-space','EL','ORIGEN'],
    ['Duna','2021 · Ciencia ficción / Aventura','Un mundo épico de política, poder y supervivencia.','poster-red','DUNA','PARTE UNO'],
    ['The Truman Show','1998 · Drama / Comedia','Una película original sobre la vida, la libertad y la verdad.','poster-neon','THE','TRUMAN SHOW']
  ]
};

function showToast(message) {
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => toast.classList.remove('show'), 2600);
}
function safeText(value) {
  return String(value).replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
}
function chooseMovies(query) {
  const q = query.toLowerCase();
  if (/terror|miedo|susto|suspenso/.test(q)) return movieSets.terror;
  if (/comedia|divertid|familia|reír|humor/.test(q)) return movieSets.comedia;
  if (/acción|accion|aventura|pelea|superhéroe|superheroe/.test(q)) return movieSets.accion;
  if (/ciencia|espacio|futur|robot|matrix|interestelar/.test(q)) return movieSets.ciencia;
  return movieSets.default;
}
function makeMovieCards(movies) {
  return `<div class="movie-grid">${movies.map(movie => `
    <article class="movie-card">
      <div class="movie-poster ${movie[3]}"><span>${safeText(movie[4])}<br><b>${safeText(movie[5])}</b></span><i>✦</i></div>
      <div class="movie-info"><h3>${safeText(movie[0])}</h3><span class="movie-meta">${safeText(movie[1])}</span><p>${safeText(movie[2])}</p></div>
    </article>`).join('')}</div>`;
}
function addHistory(question, answer) {
  const item = {question, answer, time: new Date().toLocaleTimeString('es-AR',{hour:'2-digit',minute:'2-digit'})};
  historyItems.unshift(item);
  renderHistory();
}
function renderHistory() {
  if (!historyItems.length) {
    historyList.innerHTML = '<div class="empty-history">Tus preguntas aparecerán acá.</div>';
    return;
  }
  historyList.innerHTML = historyItems.map((item,index) => `
    <button class="history-entry" data-history-index="${index}">
      <span class="history-symbol">♙</span><span>${safeText(item.question.slice(0,48))}${item.question.length>48?'…':''}<small>${item.time}</small></span>
    </button>`).join('');
  historyList.querySelectorAll('[data-history-index]').forEach(button => {
    button.addEventListener('click', () => {
      const item = historyItems[Number(button.dataset.historyIndex)];
      questionInput.value = item.question;
      lastQuestion = item.question;
      lastAnswer = item.answer;
      showToast('Consulta recuperada del historial.');
    });
  });
}
function addUserMessage(text) {
  const message = document.createElement('div');
  message.className = 'message user-message';
  message.innerHTML = `<div class="message-body"><p>${safeText(text)}</p></div>`;
  conversation.appendChild(message);
}
function addAssistantMessage(text, movies = null) {
  const message = document.createElement('div');
  message.className = 'message assistant-message';
  message.innerHTML = `<div class="avatar">✧</div><div class="message-body"><p>${safeText(text)}</p>${movies ? makeMovieCards(movies) : ''}</div>`;
  conversation.appendChild(message);
  message.scrollIntoView({behavior:'smooth', block:'nearest'});
}
function createDemoAnswer(question) {
  const q = question.toLowerCase();
  if (/resumen|resumí|resume|sinopsis/.test(q)) {
    return {text:'Modo resumen: elegí una película para que pueda prepararte una sinopsis breve. Por ejemplo, puedo resumir “Interestelar” sin contar el final.', movies:null};
  }
  if (/traduc|inglés|ingles|english/.test(q)) {
    return {text:'Modo traducción: pegá la sinopsis que querés traducir y decime a qué idioma. En esta versión de demostración, la traducción automática real se conectará al servicio de IA en una próxima etapa.', movies:null};
  }
  const movies = chooseMovies(question);
  const intro = /terror|miedo|susto|suspenso/i.test(q) ? 'Si buscás suspenso o terror, estas opciones pueden servirte:' :
    /comedia|divertid|familia|reír|humor/i.test(q) ? 'Para pasar un buen rato, podés probar con estas películas:' :
    /acción|accion|aventura|pelea/i.test(q) ? 'Acá van algunas opciones con acción y aventura:' :
    /ciencia|espacio|futur|robot|matrix|interestelar/i.test(q) ? 'Estas películas de ciencia ficción tienen mundos e ideas interesantes:' :
    '¡Buena idea! Acá tenés algunas películas para empezar a elegir:';
  return {text:intro + ' Estas son recomendaciones de ejemplo para el proyecto escolar. En una versión conectada a una API, la IA generará respuestas personalizadas según tu consulta.', movies};
}
async function submitQuestion(question) {
  const clean = question.trim();
  if (!clean) {
    validationMessage.textContent = 'Escribí una consulta antes de enviar.';
    validationMessage.classList.add('error');
    questionInput.focus();
    return;
  }
  validationMessage.textContent = 'Consulta válida. Preparando respuesta...';
  validationMessage.classList.remove('error');
  lastQuestion = clean;
  addUserMessage(clean);
  questionInput.value = '';
  charCount.textContent = '0/500';
  const response = createDemoAnswer(clean);
  lastAnswer = response.text;
  addAssistantMessage(response.text, response.movies);
  document.getElementById('answerTime').textContent = new Date().toLocaleTimeString('es-AR',{hour:'2-digit',minute:'2-digit'});
  addHistory(clean, response.text);
  validationMessage.textContent = '¡Listo! Podés hacer otra consulta.';
}
questionForm.addEventListener('submit', event => {
  event.preventDefault();
  submitQuestion(questionInput.value);
});
questionInput.addEventListener('input', () => {
  charCount.textContent = `${questionInput.value.length}/500`;
  if (questionInput.value.trim()) {
    validationMessage.textContent = 'Consulta lista para enviar.';
    validationMessage.classList.remove('error');
  }
});
document.querySelectorAll('.suggestion').forEach(button => button.addEventListener('click', () => {
  questionInput.value = button.textContent;
  charCount.textContent = `${questionInput.value.length}/500`;
  submitQuestion(questionInput.value);
}));
document.getElementById('moreRecommendations').addEventListener('click', () => {
  const question = lastQuestion || 'Recomendame películas variadas';
  const movies = chooseMovies(question);
  addAssistantMessage('Acá tenés más ideas relacionadas con tu consulta. Las recomendaciones son ejemplos para la demostración.', movies.slice().reverse());
  showToast('Se agregaron más recomendaciones.');
});
function prepareTool(type) {
  if (type === 'summary') {
    questionInput.value = lastQuestion ? `Hacé un resumen sin spoilers de una película relacionada con esta consulta: ${lastQuestion}` : 'Hacé un resumen sin spoilers de una película que me recomiendes.';
  } else {
    questionInput.value = 'Traducí esta sinopsis al inglés: [pegá acá la sinopsis de la película]';
  }
  charCount.textContent = `${questionInput.value.length}/500`;
  questionInput.focus();
  document.getElementById('askPanel').scrollIntoView({behavior:'smooth',block:'center'});
  showToast(type === 'summary' ? 'Completá o enviá la consulta para generar un resumen.' : 'Pegá el texto que querés traducir y enviá la consulta.');
}
document.getElementById('summaryAction').addEventListener('click', () => prepareTool('summary'));
document.getElementById('toolSummary').addEventListener('click', () => prepareTool('summary'));
document.getElementById('translateAction').addEventListener('click', () => prepareTool('translate'));
document.getElementById('toolTranslate').addEventListener('click', () => prepareTool('translate'));
document.getElementById('clearHistory').addEventListener('click', () => {
  historyItems = [];
  renderHistory();
  showToast('Se limpió el historial de esta sesión.');
});
document.getElementById('themeToggle').addEventListener('click', () => {
  document.body.classList.toggle('light');
  const light = document.body.classList.contains('light');
  document.getElementById('themeToggle').innerHTML = light
    ? '<span>☀</span><span>Modo claro</span><span class="toggle-track"><i style="margin-left:0"></i></span>'
    : '<span>☾</span><span>Modo oscuro</span><span class="toggle-track"><i></i></span>';
});
document.getElementById('heroStart').addEventListener('click', () => {
  questionInput.focus();
  document.getElementById('askPanel').scrollIntoView({behavior:'smooth',block:'center'});
});
document.querySelectorAll('.nav-item').forEach(button => button.addEventListener('click', () => {
  document.querySelectorAll('.nav-item').forEach(item => item.classList.remove('active'));
  button.classList.add('active');
  const view = button.dataset.view;
  if (view === 'inicio') window.scrollTo({top:0,behavior:'smooth'});
  if (view === 'recomendaciones') {
    questionInput.value = 'Recomendame películas de ciencia ficción';
    charCount.textContent = `${questionInput.value.length}/500`;
    document.getElementById('askPanel').scrollIntoView({behavior:'smooth',block:'center'});
  }
  if (view === 'resumenes') prepareTool('summary');
  if (view === 'traductor') prepareTool('translate');
}));
